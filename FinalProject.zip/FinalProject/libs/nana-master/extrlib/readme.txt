﻿You can download the precompiled external libraries at http://sourceforge.net/projects/nanapro/files/extrlib/
Extract the ZIP file to the directory nana/extrlib. Then modify the marco switch defined in nana/include/config.hpp header file and rebuild the nana library.

A method to configure the 3rd party libraries
https://github.com/cnjinhao/nana/wiki/Configuration-of-Third-Party-Libraries-for-Nana


您可以下载预先编译的外部程序库，下载地址http://sourceforge.net/projects/nanapro/files/extrlib/
将ZIP文件释放到nana/extrlib目录。然后修改nana/include/config.hpp文件中对应的标志，重新编译Nana库即可。

配置第三方库的方法
https://github.com/cnjinhao/nana/wiki/Configuration-of-Third-Party-Libraries-for-Nana