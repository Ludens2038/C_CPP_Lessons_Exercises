#ifndef GREETINGS_H
#define GREETINGS_H

void greetings(char*);

#endif