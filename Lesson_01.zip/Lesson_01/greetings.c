#include <stdio.h>

void greetings(char* text) {
    printf("%s \n", text);
}